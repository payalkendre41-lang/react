import React, { useState } from 'react'
import QuestionList from './QuestionList'
import QuizCSS from './Quiz.css'


export default function Quiz() {

  const questions=[
    {
      question: "What is javascript?",
      options:["language","framework","tool","library"],
      answer: "language"
    },
     {
      question: "What is React?",
      options:["language","framework","tool","library"],
      answer: "library"
    },
     {
      question: "What is your favorite pet?",
      options:["parrot","cat","dog","tiger"],
      answer: "cat"
    },
     {
      question: "Which breed is most favourite in cat?",
      options:["bengali","wildcat","local","persian"],
      answer: "persian"
    }
  ]

 const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
const [currentAnser, setCurrentAnswer] = useState(null);
const [score, setScore] = useState(0);
const handleClick =(option) => {
  setCurrentAnswer(option)
  if (option === questions[currentQuestionIndex].answer){
    setScore(score+1)
  }
}
const handleNextQuestion =() => {
  setCurrentQuestionIndex(currentQuestionIndex +1);
  setCurrentAnswer(null);
}
  return (
    <div> {currentQuestionIndex <questions.length? <div> <QuestionList question={questions[currentQuestionIndex].question}
     options={questions[currentQuestionIndex].options} handleClick=
     {handleClick} currentAnser={currentAnser}/>   
     <button disabled={currentAnser === null } 
     className={currentAnser === null? 'button-disable': 'button'}
     onClick={handleNextQuestion}
     >Next Question</button></div> : <div>your score is {score}</div> }
    
      </div>
  )
}
